#ifndef _CONTROL_H
#define _CONTROL_H

typedef struct clase{
	int id;
	int temp;
	int lum;
	int pres;
	char* lector;
} clase;

#endif